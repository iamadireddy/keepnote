package com.stackroute.keepnote.exception;

public class ReminderNotCreatedException extends Exception {
    
	private static final long serialVersionUID = 1L;

	public ReminderNotCreatedException(String message) {
        super(message);
    }
}
