package com.stackroute.keepnote.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Note {

	/*
	 * This class should have eight fields
	 * (noteId,noteTitle,noteContent,noteStatus,createdAt,
	 * category,reminder,createdBy). This class should also contain the getters and
	 * setters for the fields along with the no-arg , parameterized constructor and
	 * toString method. The value of createdAt should not be accepted from the user
	 * but should be always initialized with the system date.
	 * 
	 */
	@Id
	private Integer noteId;
	
	private String noteTitle;

	private String noteStatus;
	
	private String noteContent;

	private Date noteCreationDate;

	private Category category;
	
	private List<Reminder> reminders;
	
	private String noteCreatedBy;

	public Note() {	}

	public Note(Integer noteId, String noteTitle, String noteStatus, String noteContent, Date noteCreationDate,
			Category category, List<Reminder> reminders, String noteCreatedBy) {
		this.noteId = noteId;
		this.noteTitle = noteTitle;
		this.noteStatus = noteStatus;
		this.noteContent = noteContent;
		this.noteCreatedBy = noteCreatedBy;
		this.category = category;
		this.reminders = reminders;
		this.noteCreationDate = noteCreationDate;

	}

	public String getNoteStatus() {
		return noteStatus;
	}

	public Date getNoteCreationDate() {
		return noteCreationDate;
	}

	public Category getCategory() {
		return category;
	}

	public List<Reminder> getReminders() {
		return reminders;
	}

	public String getNoteCreatedBy() {
		return noteCreatedBy;
	}

	public Integer getNoteId() {
		return this.noteId;
	}

	public void setNoteId(Integer noteId) {
		this.noteId = noteId;

	}

	public String getNoteTitle() {
		return this.noteTitle;
	}

	public void setNoteTitle(String noteTitle) {
		this.noteTitle = noteTitle;

	}

	public String getNoteContent() {
		return this.noteContent;
	}

	public void setNoteContent(String noteContent) {
		this.noteContent = noteContent;

	}

	public void setNoteStatus(String noteStatus) {
		this.noteStatus = noteStatus;
	}

	public void setNoteCreationDate(Date noteCreationDate) {
		this.noteCreationDate = noteCreationDate;
	}

	public void setNoteCreatedBy(String noteCreatedBy) {
		this.noteCreatedBy = noteCreatedBy;

	}

	public void setReminders(List<Reminder> reminders) {
		this.reminders = reminders;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	@Override
	public String toString() {
		return "Note [noteId=" + noteId + ", noteTitle=" + noteTitle + ", noteStatus=" + noteStatus + ", noteContent="
				+ noteContent + ", noteCreatedAt=" + noteCreationDate + ", category=" + category + ", reminder=" + reminders
				+ ", createdBy=" + noteCreatedBy + "]";
	}
}