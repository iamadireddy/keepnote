package com.stackroute.keepnote.dao;

import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.model.Note;

/*
 * This class is implementing the NoteDAO interface. This class has to be annotated with @Repository
 * annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, thus 
 * 				 clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
public class NoteDAOImpl implements NoteDAO {

	private SessionFactory sessionFactory;

	/*
	 * Autowiring should be implemented for the SessionFactory.
	 */
	@Autowired
	public NoteDAOImpl(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}

	/*
	 * Save the note in the database(note) table.
	 */
	public boolean saveNote(Note note) {

		boolean isNoteSaved = false;
		if(note != null) {
			sessionFactory.getCurrentSession().saveOrUpdate(note);
			isNoteSaved = true;
		}
		return isNoteSaved;
	}

	/*
	 * Remove the note from the database(note) table.
	 */
	public boolean deleteNote(int noteId) {

		boolean isNoteDeleted = false;
		Note note = getNoteById(noteId);
		if(note != null) {
			sessionFactory.getCurrentSession().delete(note);
			isNoteDeleted = true;
			System.out.println("Deleted noteId is " + noteId);
		}
		return isNoteDeleted;
	}

	/*
	 * retrieve all existing notes sorted by created Date in descending
	 * order(showing latest note first)
	 */
	public List<Note> getAllNotes() {

		Query<Note> getAllNotesQ = sessionFactory.getCurrentSession().createQuery("from Note", Note.class);
		List<Note> notes = getAllNotesQ.getResultList();
		return notes;
	}

	/*
	 * retrieve specific note from the database(note) table
	 */
	public Note getNoteById(int noteId) {

		return sessionFactory.getCurrentSession().get(Note.class, noteId);
	}

	/* Update existing note */
	public boolean UpdateNote(Note note) {
		
		boolean isNoteUpdated = false;
		if(note != null) {
			sessionFactory.getCurrentSession().saveOrUpdate(note);
			isNoteUpdated = true;
		}
		
		return isNoteUpdated;
	}

	/*
	 * This method should check if the matching note id present in the list or not.
	 * Return true if note id exists in the list or return false if note id does not
	 * exists in the list
	 */
	public boolean exists(int noteId) {

		boolean isNoteExists = false;
		Note existNote = getNoteById(noteId);
		if (existNote != null) {
			isNoteExists = true;
		}
		return isNoteExists;
	}
}