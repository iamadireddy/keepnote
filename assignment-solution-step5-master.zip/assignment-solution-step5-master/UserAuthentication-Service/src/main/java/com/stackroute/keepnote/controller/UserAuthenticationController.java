package com.stackroute.keepnote.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.keepnote.exception.UserNotFoundException;
import com.stackroute.keepnote.jwt.JWTTokenGenerator;
import com.stackroute.keepnote.jwt.JWTTokenGeneratorImpl;
import com.stackroute.keepnote.model.User;
import com.stackroute.keepnote.service.UserAuthenticationService;

/*
 * As in this assignment, we are working on creating RESTful web service, hence annotate
 * the class with @RestController annotation. A class annotated with the @Controller annotation
 * has handler methods which return a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 */
@RestController
@RequestMapping("/api/v1/auth")
public class UserAuthenticationController {

	/*
	 * Autowiring should be implemented for the UserAuthenticationService. (Use
	 * Constructor-based autowiring) Please note that we should not create an object
	 * using the new keyword
	 */
	private UserAuthenticationService userAuthenticationService;
	private JWTTokenGenerator jwtTokenGenerator;

	@Autowired
	public UserAuthenticationController(UserAuthenticationService userAuthenticationService, JWTTokenGenerator jwtTokenGenerator) {
		this.userAuthenticationService = userAuthenticationService;
		this.jwtTokenGenerator = jwtTokenGenerator;
	}

	/*
	 * Define a handler method which will create a specific user by reading the
	 * Serialized object from request body and save the user details in the
	 * database. This handler method should return any one of the status messages
	 * basis on different situations: 1. 201(CREATED) - If the user created
	 * successfully. 2. 409(CONFLICT) - If the userId conflicts with any existing
	 * user
	 * 
	 * This handler method should map to the URL "/api/v1/auth/register" using HTTP
	 * POST method
	 */
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody User user) {

		try {
			User isUserExists = userAuthenticationService.findByUserIdAndPassword(user.getUserId(),
					user.getUserPassword());
			return new ResponseEntity<>(isUserExists, HttpStatus.CREATED);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.CONFLICT);
		}
	}

	/*
	 * Define a handler method which will authenticate a user by reading the
	 * Serialized user object from request body containing the username and
	 * password. The username and password should be validated before proceeding
	 * ahead with JWT token generation. The user credentials will be validated
	 * against the database entries. The error should be return if validation is not
	 * successful. If credentials are validated successfully, then JWT token will be
	 * generated. The token should be returned back to the caller along with the API
	 * response. This handler method should return any one of the status messages
	 * basis on different situations: 1. 200(OK) - If login is successful 2.
	 * 401(UNAUTHORIZED) - If login is not successful
	 * 
	 * This handler method should map to the URL "/api/v1/auth/login" using HTTP
	 * POST method
	 */
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody User user) {

		User existingUser;
		try {
			existingUser = userAuthenticationService.findByUserIdAndPassword(user.getUserId(), user.getUserPassword());
			String authToken = getToken(existingUser.getUserId(), existingUser.getUserPassword());
			return new ResponseEntity<>(authToken, HttpStatus.OK);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.CONFLICT);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.CONFLICT);
		}
	}

// Generate JWT token
	public String getToken(String username, String password) throws Exception {

		//Map<String, String> tokenMap = null;
		String token = null;
		if (username.trim().length() > 0 && username != null) {
			User user = userAuthenticationService.findByUserIdAndPassword(username, password);
			if (user != null) {
				//jwtTokenGenerator = new JWTTokenGeneratorImpl();
				token = jwtTokenGenerator.generateToken(user).get("token");
			}
		}
		return token;
	}
}