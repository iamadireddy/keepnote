package com.stackroute.keepnote.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.exception.NoteNotFoundException;
import com.stackroute.keepnote.model.Note;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
public class NoteDAOImpl implements NoteDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */
	private SessionFactory sessionFactory;

	@Autowired
	public NoteDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new note
	 */
	public boolean createNote(Note note) {

		boolean isNoteCreated = false;
		if (note != null) {
			sessionFactory.getCurrentSession().save(note);
			isNoteCreated = true;
		}
		return isNoteCreated;
	}

	/*
	 * Remove an existing note
	 */
	public boolean deleteNote(int noteId) throws NoteNotFoundException {

		boolean isNoteDeleted = false;
		Note note = null;
		if (noteId > 0) {
			note = getNoteById(noteId);
			if (note != null) {
				sessionFactory.getCurrentSession().delete(note);
				isNoteDeleted = true;
			}
		}
		return isNoteDeleted;
	}

	/*
	 * Retrieve details of all notes by userId
	 */
	public List<Note> getAllNotesByUserId(String userId) {

		return sessionFactory.getCurrentSession().createQuery("from Note where createdBy=:userid", Note.class)
				.setParameter("userid", userId).getResultList();
	}

	/*
	 * Retrieve details of a specific note
	 */
	public Note getNoteById(int noteId) throws NoteNotFoundException {

		Note note = sessionFactory.getCurrentSession().get(Note.class, noteId);
		if(note != null)
			return note;
		else
			throw new NoteNotFoundException("Note was not found");
	}

	/*
	 * Update an existing note
	 */
	public boolean UpdateNote(Note note) {

		boolean isNoteUpdated = false;
		if (note != null) {
			sessionFactory.getCurrentSession().update(note);
			isNoteUpdated = true;
		}
		return isNoteUpdated;
	}
	
	public Note updateNote(Note note, int noteId) {

		Note mynote = null;
		if (note != null) {
			if (noteId > 0) {
				try {
					mynote = getNoteById(noteId);
					if (mynote.getNoteId() == noteId)
						sessionFactory.getCurrentSession().update(note);
				} catch (NoteNotFoundException e) {
					e.printStackTrace();
				}
			}
		}
		return mynote;
	}
}