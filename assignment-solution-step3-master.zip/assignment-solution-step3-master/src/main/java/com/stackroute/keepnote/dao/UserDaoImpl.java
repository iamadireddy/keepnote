package com.stackroute.keepnote.dao;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.exception.UserNotFoundException;
import com.stackroute.keepnote.model.User;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
public class UserDaoImpl implements UserDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */
	private SessionFactory sessionFactory;

	@Autowired
	public UserDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new user
	 */
	public boolean registerUser(User user) {

		boolean isUserRegisterd = false;
		if(user != null) {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
			isUserRegisterd = true;
			System.out.println("User registered successfully..!");
		}
		return isUserRegisterd;
	}

	/*
	 * Update an existing user
	 */
	public boolean updateUser(User user) {

		boolean isUserUpdated = false;
		if(user != null) {
			sessionFactory.getCurrentSession().saveOrUpdate(user);
			isUserUpdated = true;
		}
		return isUserUpdated;
	}
	
	public User updateUser(User user, String userId) {

		User registerUser = null;
		if(user != null && userId.trim().length() > 0 && userId != null) {
			User userById = getUserById(userId);
			if(userById != null) {
				sessionFactory.getCurrentSession().saveOrUpdate(user);
				registerUser = user;
			}
		}
		return registerUser;
	}

	/*
	 * Retrieve details of a specific user
	 */
	public User getUserById(String UserId) {

		User user = null;
		if(UserId != null && UserId.trim().length() > 0) {
			user = sessionFactory.getCurrentSession().get(User.class, UserId);
		}
		return user;
	}

	/*
	 * validate an user
	 */
	public boolean validateUser(String userId, String password) throws UserNotFoundException {
		
		boolean isUserValid = false;
		if(userId != null && password != null && userId.trim().length() > 0 && password.trim().length() > 0) {
			User user = sessionFactory.getCurrentSession().createQuery("from User where userId=:userid and userPassword=:pswd", User.class)
					.setParameter("userid", userId)
					.setParameter("pswd", password).uniqueResult();
			if(user != null) {
				isUserValid = true;
			}else
				throw new UserNotFoundException("The given user was not found...");
		}
		return isUserValid;
	}

	/*
	 * Remove an existing user
	 */
	public boolean deleteUser(String userId) {

		boolean isUserDeleted = false;
		if(userId != null && userId.trim().length() > 0) {
			User user = getUserById(userId);
			if(user != null) {
				sessionFactory.getCurrentSession().delete(user);
				isUserDeleted = true;
			}
		}
		return isUserDeleted;
	}
}