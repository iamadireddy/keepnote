package com.stackroute.keepnote.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.exception.CategoryNotFoundException;
import com.stackroute.keepnote.model.Category;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
public class CategoryDAOImpl implements CategoryDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */

	private SessionFactory sessionFactory;

	@Autowired
	public CategoryDAOImpl(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new category
	 */
	public boolean createCategory(Category category) {

		boolean isCategoryCreated = false;
		if (category != null) {
			System.out.println("Inside createCategory if condition");
			sessionFactory.getCurrentSession().save(category);
			isCategoryCreated = true;
		}
		return isCategoryCreated;
	}

	/*
	 * Remove an existing category
	 */
	public boolean deleteCategory(int categoryId) {

		boolean isCategoryDeleted = false;
		Category category = null;
		try {
			if (categoryId > 0) {
				category = getCategoryById(categoryId);
				if (category != null) {
					sessionFactory.getCurrentSession().delete(category);
					isCategoryDeleted = true;
				}
			}
		} catch (CategoryNotFoundException e) {
			e.printStackTrace();
		}
		return isCategoryDeleted;
	}

	/*
	 * Update an existing category
	 */
	public boolean updateCategory(Category category) {

		boolean isCategoryUpdated = false;
		if (category != null) {
			try {
				Category categoryById = getCategoryById(category.getCategoryId());
				System.out.println("categoryById " + categoryById.getCategoryCreatedBy());
				if (categoryById != null) {
					System.out.println("Inside category DAO");
					sessionFactory.getCurrentSession().update(category);
					isCategoryUpdated = true;
				}
			} catch (CategoryNotFoundException e) {
				e.printStackTrace();
				return isCategoryUpdated;
			}
		}
		return isCategoryUpdated;
	}

	/*
	 * Update an existing category
	 */
	public Category updateCategory(Category category, int categoryId) {

		System.out.println("CategoryId is " + categoryId);
		Category myCategory = null;
		if (category != null) {
			if (categoryId > 0) {
				try {
					myCategory = getCategoryById(categoryId);
					if (myCategory.getCategoryId() == categoryId)
						sessionFactory.getCurrentSession().saveOrUpdate(category);
				} catch (CategoryNotFoundException e) {
					e.printStackTrace();
				}
			}
		}
		return myCategory;
	}

	/*
	 * Retrieve details of a specific category
	 */
	public Category getCategoryById(int categoryId) throws CategoryNotFoundException {

			Category category = sessionFactory.getCurrentSession().createQuery("from Category where categoryId = " + categoryId, Category.class).uniqueResult();
			if(category != null)
				return category;
			else 
				throw new CategoryNotFoundException("Category was not found");
	}

	/*
	 * Retrieve details of all categories by userId
	 */
	public List<Category> getAllCategoryByUserId(String userId) {

		return sessionFactory.getCurrentSession().createQuery("from Category where categoryCreatedBy=:userid", Category.class)
				.setParameter("userid", userId).getResultList();
	}
}