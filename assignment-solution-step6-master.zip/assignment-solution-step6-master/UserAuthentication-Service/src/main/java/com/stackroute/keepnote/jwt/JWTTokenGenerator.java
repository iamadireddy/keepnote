package com.stackroute.keepnote.jwt;

import java.util.Map;

import com.stackroute.keepnote.model.User;

public interface JWTTokenGenerator {

	Map<String, String> generateToken(User user);
}