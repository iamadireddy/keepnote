package com.stackroute.keepnote.jwt;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.stackroute.keepnote.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JWTTokenGeneratorImpl implements JWTTokenGenerator {

	@Override
	public Map<String, String> generateToken(User user) {

		String jwtToken = Jwts.builder().setIssuer("AuthUser").setSubject(user.getUserId())
				.claim("userRole", user.getUserRole()).setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS512, "UserAuthSecret").compact();

		Map<String, String> tokenMap = new HashMap<String, String>();
		tokenMap.put("token", jwtToken);
		tokenMap.put("message", "User " + user.getUserId() + " is authenticated");

		return tokenMap;

	}

}
