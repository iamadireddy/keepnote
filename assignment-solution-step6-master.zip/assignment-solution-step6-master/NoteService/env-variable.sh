#!/usr/bin/env bash
export MONGO_DATABASE=note
export MONGO_USERNAME=root
export MONGO_PASSWORD=myPassword
export MONGO_PORT=27017
export MONGO_HOST=localhost