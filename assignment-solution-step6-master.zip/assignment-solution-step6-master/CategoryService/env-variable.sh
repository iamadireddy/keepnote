#!/usr/bin/env bash
export MONGO_DATABASE=category
export MONGO_USERNAME=root
export MONGO_PASSWORD=myPassword
export MONGO_PORT=27017
export MONGO_HOST=localhost
#export MONGO_URI=mongodb://localhost:27017/category